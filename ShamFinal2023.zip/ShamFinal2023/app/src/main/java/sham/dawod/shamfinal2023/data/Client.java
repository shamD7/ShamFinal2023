package sham.dawod.shamfinal2023.data;

public class Client
{
    private String  Cname;
}
