package sham.dawod.shamfinal2023.data;

public class Dessert extends Meal
{
}
