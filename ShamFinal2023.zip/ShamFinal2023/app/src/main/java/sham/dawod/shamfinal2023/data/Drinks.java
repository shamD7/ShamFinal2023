package sham.dawod.shamfinal2023.data;

public class Drinks
{
   private int price ;
   private  String name;
   private String kind;
}
