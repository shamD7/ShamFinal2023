package sham.dawod.shamfinal2023.data;

public class Location
{
    private double lang ;// خط الطول
    private double lat ; //خط العرض
}

