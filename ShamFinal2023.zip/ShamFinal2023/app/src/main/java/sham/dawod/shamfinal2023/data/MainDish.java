package sham.dawod.shamfinal2023.data;

public class MainDish extends Meal
{
}
