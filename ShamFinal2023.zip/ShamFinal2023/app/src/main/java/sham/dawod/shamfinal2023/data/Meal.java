package sham.dawod.shamfinal2023.data;

public class Meal
{
    protected int price;
    protected String name;
    protected String ingredients;
}
