package sham.dawod.shamfinal2023.data;

public class OwnerUser
{
    private String Oname;
    private String HisRest;//معطمه

}
